#include <iostream>
using namespace std;

class Node{
  public:
    int val;
    Node * next; 
//next is a pointer (not an object), 
//it will not invoke the Node constructor
    
    Node(int val, Node * next) {
      this->val = val;
      this->next = next;
    }
};


int countNodes(const Node* current) {
    int count=0;
    while (current != nullptr) { ++count; current=current->next; }
    return count;
}
int main() {
    Node c(30,nullptr), b(20,&c), a(10,&b);
    cout << countNodes(&a) << " " << countNodes(nullptr) << "\n";
}
