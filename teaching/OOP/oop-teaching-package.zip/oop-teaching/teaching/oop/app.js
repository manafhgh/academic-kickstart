'use strict';
const DATA = window.OOP_DATA;
const byId = new Map(DATA.examples.map(e => [e.id, e]));
const safe = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function highlight(code) {
    const re = /(\/\*[\s\S]*?\*\/|\/\/[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\b(?:class|public|private|protected|const|constexpr|static|virtual|override|return|if|else|for|while|int|float|double|bool|char|void|new|delete|nullptr|using|namespace|friend|explicit|default|try|catch|throw|true|false|long)\b|\b\d+(?:\.\d+)?\b)/g;
    let result='', last=0;
    for (const m of code.matchAll(re)) {
        result += safe(code.slice(last,m.index));
        const v=m[0], kind=v.startsWith('//')||v.startsWith('/*')?'comment':v[0]==='"'||v[0]==="'"?'string':/^\d/.test(v)?'number':'keyword';
        result += `<span class="${kind}">${safe(v)}</span>`;
        last=m.index+v.length;
    }
    return result+safe(code.slice(last));
}
function saved(key,fallback) { try{return localStorage.getItem('oop-v1-'+key) ?? fallback;}catch{return fallback;} }
function save(key,value) { try{localStorage.setItem('oop-v1-'+key,value);}catch{} }
function runner(e, id=e.id, isSolution=false) {
    const original=e.code, current=saved(id+'-code',original);
    return `<div class="runner" data-id="${safe(id)}" data-source="${safe(e.id)}" data-solution="${isSolution}">
        <div class="toolbar"><button class="primary" data-action="run">Run ▶</button><button data-action="edit" aria-pressed="false">Edit code</button><button data-action="copy">Copy</button><button data-action="download">Download .cpp</button><button data-action="reset">Reset</button><span class="language">C++17 · GCC 13.2</span></div>
        <pre class="code-view" tabindex="0" aria-label="C++ source code"><code>${highlight(current)}</code></pre>
        <textarea class="editor" aria-label="Edit C++ source code" spellcheck="false" autocapitalize="off" hidden>${safe(current)}</textarea>
        <div class="io"><div><label for="input-${safe(id)}">Standard input (cin)</label><textarea id="input-${safe(id)}" class="stdin" aria-label="Standard input" placeholder="Enter input before running">${safe(saved(id+'-stdin',e.stdin||''))}</textarea></div><div><span class="output-label">Output / compiler messages</span><pre class="output" aria-live="polite">Run the program to see its output.</pre></div></div>
        <div class="status" role="status"></div>
        ${e.output!==undefined?`<details class="sample"><summary>Verified sample output${e.stdin?' (using the supplied input)':''}</summary><pre>${safe(e.output)}</pre></details>`:''}
    </div>`;
}
function render() {
    document.querySelector('#topics').innerHTML=DATA.topics.map(t => {
        const ex=t.exercise, base=byId.get(ex.example);
        const sol={id:ex.id,code:ex.solution,stdin:ex.stdin,output:ex.output};
        return `<section class="topic" id="${t.id}"><div class="topic-head"><div><span class="eyebrow">Topic ${String(t.number).padStart(2,'0')}</span><h2>${safe(t.title)}</h2></div><label><input class="complete" type="checkbox" data-topic="${t.id}" ${saved(t.id+'-done','')==='yes'?'checked':''}> Mark reviewed</label></div><p class="topic-intro">${safe(t.intro)}</p>
        ${DATA.examples.filter(e=>e.topic===t.id).map((e,i)=>`<details class="example" ${i===0?'open':''}><summary>${safe(e.title)}<small>${safe(e.origin)}</small></summary><div class="example-body"><p class="note">${safe(e.note)}</p>${runner(e)}</div></details>`).join('')}
        <div class="practice"><h3>Check your understanding</h3><span class="exercise-label">01 · Think first</span><p>${safe(t.question)}</p><details class="answer"><summary>Reveal explanation</summary><p>${safe(t.answer)}</p></details><hr style="border:0;border-top:1px solid #e4e5d6;margin:1.3rem 0"><span class="exercise-label">02 · Build and test</span><p>${safe(ex.task)}</p><details class="answer"><summary>Hint</summary><p>${safe(ex.hint)}</p></details>
        <details class="example"><summary>Practice workspace<small>Starts with ${safe(base.title)}. Edit the code to complete the task.</small></summary><div class="example-body">${runner(base,'workspace-'+t.id)}</div></details>
        <details class="solution"><summary>Reveal a worked solution</summary><p>${safe(ex.explanation)}</p>${runner(sol,ex.id,true)}</details><p class="footnote">Compare your reasoning and output with the solution. These exercises are for practice; running code does not automatically grade it.</p></div></section>`;
    }).join('');
    document.querySelector('#topic-nav').innerHTML=DATA.topics.map(t=>`<a href="#${t.id}" data-topic="${t.id}">${String(t.number).padStart(2,'0')} · ${safe(t.title)}</a>`).join('');
    updateProgress();
}
function updateProgress() {
    const count=document.querySelectorAll('.complete:checked').length;
    document.querySelector('#progress').value=count;
    document.querySelector('#progress-text').textContent=`${count} of ${DATA.topics.length} topics reviewed`;
}
let activeRequest=null;
function resultText(data) {
    const lines=arr=>(arr||[]).map(x=>x.text||'').join('\n');
    const build=data.buildResult||data;
    const sections=[];
    const diagnostics=lines(build.stderr);
    if (diagnostics) sections.push('Compiler messages:\n'+diagnostics.replace(/\x1b\[[0-9;]*m/g,''));
    if (build.code!==0) { sections.push('Compilation failed.'); return sections.join('\n\n'); }
    if (!data.didExecute && !data.execResult) { sections.push('Compiled, but execution was not returned by the service.');return sections.join('\n\n'); }
    const execution=data.execResult||data;
    sections.push(lines(execution.stdout)||'(No standard output)');
    const error=lines(execution.stderr);if(error)sections.push('Standard error:\n'+error);
    sections.push(`Exit code: ${execution.code ?? 'unknown'}${execution.timedOut?' · execution timed out':''}${execution.truncated?' · output truncated':''}`);
    return sections.join('\n\n');
}
async function runProgram(container) {
    if(activeRequest){container.querySelector('.status').textContent='Another program is running. Please wait.';return;}
    const code=container.querySelector('.editor').value;
    const input=container.querySelector('.stdin').value;
    const out=container.querySelector('.output'),status=container.querySelector('.status');
    const controller=new AbortController();activeRequest=controller;
    const timer=setTimeout(()=>controller.abort(),45000);
    document.querySelectorAll('[data-action="run"]').forEach(b=>b.disabled=true);
    out.textContent='Compiling and running…';status.textContent='Sending code and input to Compiler Explorer.';
    try {
        const response=await fetch('https://godbolt.org/api/compiler/g132/compile',{
            method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},signal:controller.signal,
            body:JSON.stringify({source:code,options:{userArguments:'-std=c++17 -Wall -Wextra -pedantic',compilerOptions:{executorRequest:true},filters:{execute:true},executeParameters:{args:[],stdin:input},tools:[],libraries:[]},lang:'c++',allowStoreCodeDebug:false})
        });
        if(!response.ok)throw new Error('Compiler service returned HTTP '+response.status);
        out.textContent=resultText(await response.json());status.textContent='Finished. Output corresponds to the code and input submitted when Run was clicked.';
    } catch(error) {
        out.textContent=error.name==='AbortError'?'The request timed out. Try a smaller program or try again later.':`${error.message}\nThe compiler service may be unavailable. Download the code and run it locally, or copy it into https://godbolt.org/.`;
        status.textContent='Run could not be completed.';
    } finally {
        clearTimeout(timer);activeRequest=null;
        document.querySelectorAll('[data-action="run"]').forEach(b=>b.disabled=false);
    }
}
function originalFor(container) {
    if(container.dataset.solution==='true')return DATA.topics.find(t=>t.exercise.id===container.dataset.id).exercise.solution;
    return byId.get(container.dataset.source).code;
}
let toastTimer;
function toast(message) { const el=document.querySelector('#toast');el.textContent=message;el.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.hidden=true,2500); }
document.addEventListener('click',async event=>{
    const button=event.target.closest('button[data-action]');if(!button)return;
    const container=button.closest('.runner');if(!container)return;
    const editor=container.querySelector('.editor'),view=container.querySelector('.code-view');
    switch(button.dataset.action) {
        case 'run': await runProgram(container);break;
        case 'edit': {
            const show=editor.hidden;editor.hidden=!show;view.hidden=show;
            if(!show)view.querySelector('code').innerHTML=highlight(editor.value);
            button.textContent=show?'View code':'Edit code';button.setAttribute('aria-pressed',String(show));
            if(show)editor.focus();break;
        }
        case 'copy':try{await navigator.clipboard.writeText(editor.value);toast('Code copied.');}catch{editor.hidden=false;view.hidden=true;editor.focus();editor.select();toast('Select and copy the code manually.');}break;
        case 'download': {
            const url=URL.createObjectURL(new Blob([editor.value],{type:'text/plain'}));
            const a=document.createElement('a');a.href=url;a.download=container.dataset.id+'.cpp';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);break;
        }
        case 'reset': {
            if(editor.value!==originalFor(container) && !confirm('Restore the original code and input? Your edits in this workspace will be replaced.'))break;
            editor.value=originalFor(container);view.querySelector('code').innerHTML=highlight(editor.value);
            const stdin=container.dataset.solution==='true'?DATA.topics.find(t=>t.exercise.id===container.dataset.id).exercise.stdin:byId.get(container.dataset.source).stdin;
            container.querySelector('.stdin').value=stdin||'';
            save(container.dataset.id+'-code',editor.value);save(container.dataset.id+'-stdin',stdin||'');
            container.querySelector('.output').textContent='Run the program to see its output.';container.querySelector('.status').textContent='Original code restored.';break;
        }
    }
});
document.addEventListener('input',event=>{
    const runner=event.target.closest('.runner');if(!runner)return;
    if(event.target.matches('.editor'))save(runner.dataset.id+'-code',event.target.value);
    if(event.target.matches('.stdin'))save(runner.dataset.id+'-stdin',event.target.value);
});
document.addEventListener('keydown',event=>{
    if(event.target.matches('.editor')&&event.key==='Tab') {
        event.preventDefault();const el=event.target,start=el.selectionStart,end=el.selectionEnd;
        el.setRangeText('    ',start,end,'end');el.dispatchEvent(new Event('input',{bubbles:true}));
    }
});
document.addEventListener('change',event=>{
    if(event.target.matches('.complete')){save(event.target.dataset.topic+'-done',event.target.checked?'yes':'');updateProgress();}
});
document.querySelector('#search').addEventListener('input',event=>{
    const q=event.target.value.trim().toLowerCase();let visible=0;
    DATA.topics.forEach(t=>{
        const searchable=[t.title,t.intro,t.question,t.exercise.task,...DATA.examples.filter(e=>e.topic===t.id).flatMap(e=>[e.title,e.note,e.code])].join(' ').toLowerCase();
        const matches=!q||searchable.includes(q);
        document.getElementById(t.id).hidden=!matches;
        document.querySelector(`#topic-nav a[data-topic="${t.id}"]`).hidden=!matches;
        if(matches)visible++;
    });
    document.querySelector('#no-results').hidden=visible!==0;
    document.querySelector('#search-status').textContent=q?`${visible} matching topics`:'';
});
document.querySelector('#print').addEventListener('click',()=>window.print());
render();
if('IntersectionObserver' in window) {
    const observer=new IntersectionObserver(entries=>{
        entries.forEach(entry=>{if(entry.isIntersecting){document.querySelectorAll('#topic-nav a').forEach(a=>a.classList.toggle('active',a.dataset.topic===entry.target.id));}});
    },{rootMargin:'-10% 0px -65% 0px'});
    document.querySelectorAll('.topic').forEach(t=>observer.observe(t));
}
