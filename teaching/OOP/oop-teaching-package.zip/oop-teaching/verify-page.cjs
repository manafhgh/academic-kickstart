// Logic and generated-markup checks; this is not a browser rendering test.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/teaching/oop/';
const elements=new Map();
const get=selector=>{
  if(!elements.has(selector))elements.set(selector,{innerHTML:'',textContent:'',value:0,addEventListener(){},hidden:true});
  return elements.get(selector);
};
const data={examples:JSON.parse(fs.readFileSync(root+'content.json')),topics:JSON.parse(fs.readFileSync(root+'topics.json'))};
const memory=new Map();
const context={window:{OOP_DATA:data,print(){}},document:{querySelector:get,querySelectorAll:()=>[],addEventListener(){}},
  localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v)},setTimeout,clearTimeout,AbortController,
  navigator:{},console,Blob,URL,confirm:()=>true,Event};
vm.createContext(context);vm.runInContext(fs.readFileSync(root+'app.js','utf8'),context);
assert.equal((get('#topics').innerHTML.match(/<section class="topic"/g)||[]).length,24);
assert.equal((get('#topics').innerHTML.match(/class="runner"/g)||[]).length,80);
assert.equal((get('#topic-nav').innerHTML.match(/<a /g)||[]).length,24);
assert.equal(vm.runInContext('safe("<script>&")',context),'&lt;script&gt;&amp;');
assert(vm.runInContext('highlight("// <script>\\nint x=5;")',context).includes('&lt;script&gt;'));
assert.equal(vm.runInContext('resultText({code:0,didExecute:true,stdout:[{text:"42"}],stderr:[],buildResult:{code:0,stderr:[]}})',context),'42\n\nExit code: 0');
assert(vm.runInContext('resultText({code:1,stderr:[{text:"bad source"}]})',context).includes('Compilation failed'));
assert(vm.runInContext('resultText({code:0,stdout:[],stderr:[]})',context).includes('execution was not returned'));
assert(vm.runInContext('resultText({code:1,didExecute:true,stdout:[],stderr:[{text:"bad input"}],buildResult:{code:0,stderr:[]}})',context).includes('Exit code: 1'));
const fields={'.editor':{value:'int main(){return 0;}'},'.stdin':{value:'21\n'},'.output':{textContent:''},'.status':{textContent:''}};
context.container={querySelector:s=>fields[s]};
let payload;
context.fetch=async(url,options)=>{
  assert.equal(url,'https://godbolt.org/api/compiler/g132/compile');payload=JSON.parse(options.body);
  return {ok:true,json:async()=>({code:0,didExecute:true,stdout:[{text:'42'}],buildResult:{code:0,stderr:[]}})};
};
(async()=>{
  await vm.runInContext('runProgram(container)',context);
  assert.equal(payload.source,fields['.editor'].value);assert.equal(payload.options.executeParameters.stdin,'21\n');
  assert(fields['.output'].textContent.includes('42'));assert(fields['.status'].textContent.includes('Finished'));
  context.fetch=async()=>{throw new Error('Network unavailable');};
  await vm.runInContext('runProgram(container)',context);
  assert(fields['.output'].textContent.includes('Download the code'));assert(fields['.status'].textContent.includes('could not'));
  console.log('Page markup, escaping, syntax highlighting, output handling, Run payload, and service-failure checks passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
